#
# Regular cron jobs for the fisygradis package
#
0 4	* * *	root	fisygradis_maintenance
