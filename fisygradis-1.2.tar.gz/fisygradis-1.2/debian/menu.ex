?package(fisygradis):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="fisygradis" command="/usr/bin/fisygradis"
