# Defaults for fisygradis initscript
# sourced by /etc/init.d/fisygradis
# installed at /etc/default/fisygradis by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
