/* position.h */

#ifndef POSITION_H
#define POSITION_H

#include <GL/gl.h>

#define FOV 85
#define WIDTH 1200
#define HEIGHT 800
#define MAX_FILE 200

/*
 * GLM header files
 */
#include "gltb.h"
#include "glm.h"
#include "dirent32.h"


extern GLint T0;
extern GLint Frames;

extern float origx;
extern float origy;
extern float origz;
extern char* path;
extern GLuint material_mode; 
extern int inside;
extern int helpmenu;
extern int helpinfo;
extern int poutline;
extern int fog;
extern int bfcull;
extern int usetex;
extern int hide_names;
extern int hide_coord;
extern int hide_time;
extern int hide_size;
extern int zoom_in;
extern int zoom_out;
extern int cursor;

extern float dir[3];
extern float indir[3];
extern float v;
extern float zoom;
extern float expand;
extern float alpha;
extern float beta;
extern float inalpha;
extern float inbeta;

extern char*      model_file[];
extern GLboolean  facet_normal;
extern GLMmodel*  model;			      
extern GLfloat    scale;			      
extern GLfloat    smoothing_angle;

extern void calcposobs(void);
extern void calcposin(void);
extern void output(float x, float y, char string[]);
extern void printstring(void *font, char *string);
extern void printhelp(void); 
extern void printinfo(void); 
extern void key(unsigned char k, int x, int y);
extern void special(int k, int x, int y);
extern void drawObject(char *file_path);
//extern void addObject(void);

#endif
