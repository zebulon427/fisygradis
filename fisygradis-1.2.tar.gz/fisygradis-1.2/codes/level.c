/** @file level.c 
  @brief Contains the functions generating the tree and recursively parsing the file system.
This file determines, by the use of 2 distinct functions, the position of the directory and file objects in the space. Prior to that , it does parse the file system recursively to create each object.
At last, the do_a_directory funtion creates a Binary Search Tree to store the parameters of each directory for use in main.c.

void do_a_directory(char * pathname, GLfloat level)
is a function taken from: 
http://docs.linux.cz/programming/c/unix_examples/dtree.html
fisygradis_post2

    @author Francois Gez
    @date 08/04/2007
*/

/* POSIX file system access headers */
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/param.h>

#include <time.h>
#include <stdio.h>
#include <stdlib.h> 
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <GL/glut.h>
#include "level.h"
#include "position.h"
#include "tree.h"
#include "component.h"

//Time Access, modified and changed handling data
#define FMT_TIME "%d/%m/%Y-%T" 
#define MAX_BUF 1000 

//Object coordinate declared and initialised here
GLfloat depth = BRANCH;
GLfloat incl = 0.0;
GLfloat placement = 0.0;
GLfloat deport = 15.0;
GLfloat spiral = 1.0;
GLfloat xpos, zpos, level;
struct dirent * entry;          /* Only used as a pointer - see dirent.h */
static char coordinate[200] = "";
static char file_size[200] = "";
static char file_time[300] = "";
int counter = 0;
//BST Structures necessary to store nodes' details
SearchTree T;
Position P;



/** This function creates and positions the directory object.   
    @return void there is nothing to return
    @param pathname char* this string holds the pathname of each directory.
    @param xpos GLfloat the x coordinate of the directory.
    @param zpos GLfloat the z coordinate of the directory.
    @param level GLfloat the y coordinate of the directory.
*/
void 
do_a_directory(char *pathname, GLfloat xpos, GLfloat zpos, GLfloat level, GLenum mode)
{  
  DIR * directory;                /* Like a FILE *, but for directories. */
  struct stat statbuf;            /* So we can check which files are directories. */
  char * newname;                 /* Name of directory at next level. */
  
  long where;                     /* We will leave this directory and come */
  /* back - need to remember where we were. */
  int retval;
  GLuint inode;
  
  calcposobs();
  
  /* Open a directory for directory reads. */
  directory = opendir(pathname);
  if(directory == NULL)
    {
      fprintf(stderr, "Cannot open %s\n", pathname);
      perror("Reason");
      return;
    }
  
  while( ( entry = readdir(directory)) != NULL)
    {
      
      /* Skip if . or .. */
      if( strcmp(entry -> d_name, ".") == 0 ||
	  strcmp(entry -> d_name, "..") == 0 )
	{
	  
	  level ++;
	  placement = depth;
	  glTranslatef(0.0,placement,0.0);
	  
	  glRotatef(-deport,0.0,0.0,1.0);
	  glTranslatef(0.0, -placement,0.0);	
	  continue;
	}
      
      /* Skip if special file */
      if (entry->d_type == DT_LNK) 
	{
	  continue;
	}
      if (entry->d_type == DT_BLK) 
	{
	  continue;
	}      
      if (entry->d_type == DT_CHR) 
	{
	  continue;
	}     
      if (entry->d_type == DT_FIFO) 
	{
	  continue;
	}     
      if (entry->d_type == DT_SOCK) 
	{	       	
	  continue;
	}     
      inode = entry -> d_ino;      
      
      /* Manufacture pathname of entry relative to where we started. */
      
      newname = (char *) malloc(MAXPATHLEN);
      strcpy(newname, pathname);
      strcat(newname, "/");
      strcat(newname, entry -> d_name);

      /* stat it to see if it is a directory. */
      retval = stat(newname, &statbuf);
      if (retval == 0 &&  ( statbuf.st_mode & S_IFDIR))
	{	   
	  where = telldir(directory);
	  closedir(directory);
	  
	  
	  if(mode == GL_SELECT)
	    {
	      glLoadName(inode);
	      
	      T = Insert(statbuf, inode, newname, T); 	  
	    }  		
	  
	  //OpenGL stuff
	  glTranslatef(0.0,placement,0.0);
	  
	  glPushMatrix();
	  
	  
	  /*Build cylinder*/	  
	  glPushMatrix();		  

	  glTranslatef(0.0, 0.0,level);
	  glRotatef(incl+270.0,incl+270.0,0.0, 1.0);	      
	  glTranslatef(0.0,0.0,depth/2 );//Rattrapage
	  glBindTexture(GL_TEXTURE_2D, texture_id[MARBLE_TEXTURE]);
	  glCallList(cylinder);

	  glPushMatrix();	  

	  if(hide_names)
	    output(1.0, 0.0, entry->d_name);

	  glTranslatef(0.0,1.0,depth/2 );//Rattrapage
	  glRotatef(90.0-incl,90.0-incl,0.0, 1.0);	      
	  glBindTexture(GL_TEXTURE_2D, texture_id[GOLD_TEXTURE]);	  
	  glCallList(plate);	    	  
	  
      	  sprintf(coordinate, "Inode: %d, Dev: %d, Permission: User  %d, Group %d ",statbuf.st_ino,statbuf.st_dev, statbuf.st_uid, statbuf.st_gid );	  
	  if(!hide_coord)
	    output(0, -3,coordinate);
	  
	  if(!hide_time)
	    {
	      char date1[MAX_BUF];
	      char date2[MAX_BUF];
	      char date3[MAX_BUF]; 
    
	      strftime (date1,sizeof date1,FMT_TIME, gmtime (&statbuf.st_mtime));
	      strftime (date2,sizeof date2,FMT_TIME, gmtime (&statbuf.st_atime));
	      strftime (date3,sizeof date3,FMT_TIME, gmtime (&statbuf.st_ctime)); 
	      sprintf(file_time, "Last access: %s Last mod: %s Last changed: %s", date1, date2, date3); 
	      output(0, 0, file_time);	  
	    }
	  
	  glPopMatrix();
	  glPopMatrix();
   	  //end OpenGL bit
	  
	  //Recursion function here:
	  do_a_directory(newname, xpos, zpos, level, mode);
	  placement = depth;
	  glPopMatrix();
	  
	  directory = opendir(pathname);
	  if(directory == NULL)
	    {
	      fprintf(stderr, "Cannot open %s\n", pathname);
	      return;
	    }
          seekdir(directory, where);
	  
	} // end if directory
      
      free(newname);
    }//end while
  
  closedir(directory);
  level --;         
  placement = 0.0;  
}


/** This function creates and positions the file or directory object contained in the current open directory which has been selected.   
    @return void there is nothing to return
    @param pathname char* this string holds the pathname of each file.
    @param xpos GLfloat the x coordinate of the file or directory.
    @param zpos GLfloat the z coordinate of the file or directory.
    @param level GLfloat the y coordinate of the file or directory.
*/
void 
do_a_file(char * pathname, GLfloat xpos, GLfloat zpos)
{  
  DIR * directory;                /* Like a FILE *, but for directories. */
  struct dirent * entry;          /* Only used as a pointer - see dirent.h */
  char * newname;                 /* Name of directory at next level. */
  GLfloat push_away = 5.0;
  struct stat statbuf;            /* So we can check which files are directories. */
  
  /* read in the model */
  
  long where;                     /* We will leave this directory and come */
  /* back - need to remember where we were. */
  int retval;
  int inode;  
  calcposin();
  
  /* Open a directory for directory reads. */
  directory = opendir(pathname);
  if(directory == NULL)
    {
      fprintf(stderr, "Cannot open %s\n", pathname);
      perror("Reason");
      return;
    }
  
  while( ( entry = readdir(directory)) != NULL)
    {
      /* Skip if . or .. */
      if( strcmp(entry -> d_name, ".") == 0 ||
	  strcmp(entry -> d_name, "..") == 0 )
	{
	  glTranslatef(0.0,10.0,0.0);
	  continue;
	}
      
      /* Skip if special file */
      if (entry->d_type == DT_LNK) 
	{
	  continue;
	}
      if (entry->d_type == DT_BLK) 
	{
	  continue;
	}      
      if (entry->d_type == DT_CHR) 
	{
	  continue;
	}     
      if (entry->d_type == DT_FIFO) 
	{
	  continue;
	}     
      if (entry->d_type == DT_SOCK) 
	{	       	
	  continue;
	}     
      inode = (int) entry -> d_ino;      
      
      
      /* Manufacture pathname of entry relative to where we started. */
      
      newname = (char *) malloc(MAXPATHLEN);
      strcpy(newname, pathname);
      strcat(newname, "/");
      strcat(newname, entry -> d_name);
      /* stat it to see if it is a directory. */
      retval = stat(newname, &statbuf);   
      where = telldir(directory);
      closedir(directory);
      
      if(spiral>25)
	glTranslatef(0.0,push_away,0.0);	  
      push_away += 0.5;
      glTranslatef(5.0,0.0,0.0);	  
      glTranslatef(0.0,0.0,2.0);	  
      glRotatef(deport,0.0,0.0, 1.0);
      
      /*Build directory*/	        
      if (entry->d_type == DT_DIR)
	{	   	  
	  glPushMatrix();
	  
	  if(hide_names)
	    output(1.0, 0.0, entry->d_name);
	  
	  glBindTexture(GL_TEXTURE_2D, texture_id[GOLD_TEXTURE]);

	  glCallList(plate);	    
	  

	  sprintf(coordinate, "Inode: %d, Dev: %d, Permission: User  %d, Group %d ",statbuf.st_ino,statbuf.st_dev, statbuf.st_uid, statbuf.st_gid );	  
	  if(!hide_coord)
	    output(2.0, 0.0,coordinate);	  	  
	  glPopMatrix();
	}
      
      /* Build file */
      
      
      else if (entry->d_type == DT_REG) 	
	{	  
	  /* read in the model */

	  
	  glPushMatrix();	

	  if(hide_names)
	    output(1.0, 1.0, entry -> d_name);
	  
	  glBindTexture(GL_TEXTURE_2D, texture_id[MARBLE_TEXTURE]);
	  
	  if(strstr(&entry->d_name, ".deb"))
	    drawObject(model_file[1]);
	  else if(strstr(&entry->d_name, ".bz2") || strstr(&entry->d_name, ".gz") || strstr(&entry->d_name, ".jar")|| strstr(&entry->d_name, ".tar") || strstr(&entry->d_name, ".zip"))
	    drawObject(model_file[2]);	  
	  else if(strstr(&entry->d_name, ".iso") || strstr(&entry->d_name, ".img"))
	    drawObject(model_file[3]);	  
	  else if(strstr(&entry->d_name, ".abw") || strstr(&entry->d_name, ".doc") || strstr(&entry->d_name, ".odt") || strstr(&entry->d_name, ".rtf") || strstr(&entry->d_name, ".txt"))
	    drawObject(model_file[4]);	  
	  else if(strstr(&entry->d_name, ".html") || strstr(&entry->d_name, ".xml"))
	    drawObject(model_file[5]);
	  else if(strstr(&entry->d_name, ".pdf") || strstr(&entry->d_name, ".ps") || strstr(&entry->d_name, ".css") )
	    drawObject(model_file[6]);
	  else if(strstr(&entry->d_name, ".gif") || strstr(&entry->d_name, ".jpeg") || strstr(&entry->d_name, ".jpg") || strstr(&entry->d_name, ".png") || strstr(&entry->d_name, ".rgb"))
	    drawObject(model_file[7]);
	  else if(strstr(&entry->d_name, ".out") || strstr(&entry->d_name, ".exe") || strstr(&entry->d_name, ".class"))
	    drawObject(model_file[8]);
	  else if(strstr(&entry->d_name, ".odp") || strstr(&entry->d_name, ".pps") || strstr(&entry->d_name, ".odt") || strstr(&entry->d_name, ".ppt"))
	    drawObject(model_file[9]);
	  else if(strstr(&entry->d_name, ".asp") || strstr(&entry->d_name, ".js") || strstr(&entry->d_name, ".php") || strstr(&entry->d_name, ".cgi"))
	    drawObject(model_file[10]);
	  //  else if(strstr(&entry->d_name, ".odp") || strstr(&entry->d_name, ".pps") || strstr(&entry->d_name, ".odt") || strstr(&entry->d_name, ".ppt"))
	  // drawObject(model_file[11]);
	  else if(strstr(&entry->d_name, ".py") || strstr(&entry->d_name, ".sh"))
	    drawObject(model_file[11]);
	  else if(strstr(&entry->d_name, ".au") || strstr(&entry->d_name, ".wav") || strstr(&entry->d_name, ".ogg") || strstr(&entry->d_name, ".mp3"))
	    drawObject(model_file[12]);
	  else if(strstr(&entry->d_name, ".odp") || strstr(&entry->d_name, ".pls") || strstr(&entry->d_name, ".m3u"))
	    drawObject(model_file[13]);
	  else if(strstr(&entry->d_name, ".c") || strstr(&entry->d_name, ".e") || strstr(&entry->d_name, ".h") || strstr(&entry->d_name, ".hpp") || strstr(&entry->d_name, ".java") || strstr(&entry->d_name, ".l") || strstr(&entry->d_name, ".y") || strstr(&entry->d_name, ".pl"))
	    drawObject(model_file[14]);
	  else if(strstr(&entry->d_name, ".gnumeric") || strstr(&entry->d_name, ".xls"))
	    drawObject(model_file[15]);
	  else if(strstr(&entry->d_name, ".avi") || strstr(&entry->d_name, ".swf") || strstr(&entry->d_name, ".mpeg") || strstr(&entry->d_name, ".mpg") || strstr(&entry->d_name, ".wmv"))
	    drawObject(model_file[16]);  
	  else
	    glCallList(cube);
	  
  if(!hide_coord)
    {
    sprintf(coordinate, "Inode: %d, Dev: %d, Permission: User  %d, Group %d,Links: %d",statbuf.st_ino,statbuf.st_dev, statbuf.st_uid, statbuf.st_gid, statbuf.st_nlink);	  
      output(2, 0,coordinate);
    }
  if(!hide_size)
    {
      output(0, 0, file_size);	  
      sprintf(file_size, "Size: %d", statbuf.st_size);
    }
  
  if(!hide_time)
    {
      char date1[MAX_BUF];
      char date2[MAX_BUF];
      char date3[MAX_BUF]; 
      
      strftime (date1,sizeof date1,FMT_TIME, gmtime (&statbuf.st_mtime));
      strftime (date2,sizeof date2,FMT_TIME, gmtime (&statbuf.st_atime));
      strftime (date3,sizeof date3,FMT_TIME, gmtime (&statbuf.st_ctime)); 
      sprintf(file_time, "Last access: %s Last mod: %s Last changed: %s", date1, date2, date3); 
      output(0, 0, file_time);	  
    }
  
  glPopMatrix();	  
	} 
      //end OpenGL bit
      
      directory = opendir(pathname);
      if(directory == NULL)
	{
	  fprintf(stderr, "Cannot open %s\n", pathname);
	  return;
	}
      seekdir(directory, where);      
      free(newname);
      spiral ++;
    }//end while
  closedir(directory);
}

