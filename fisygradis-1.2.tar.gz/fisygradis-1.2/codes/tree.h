/*http://www.cs.fiu.edu/~weiss/dsaa_c2e/files.html*/

#include <GL/glut.h>
#include <sys/types.h>
#include <sys/stat.h>

        typedef int ElementType;
        typedef GLfloat Coordinate;

/* START: fig4_16.txt */
        #ifndef _MyTree_H
        #define _MyTree_H

        struct TreeNode;
        typedef struct TreeNode *Position;
        typedef struct TreeNode *SearchTree;

//extern struct store st;
extern SearchTree T;
extern Position P; 

SearchTree MakeEmpty( SearchTree T );
extern char* FindPath( int inode, SearchTree T );

extern SearchTree Insert(struct stat astat, int inode, char* apath, SearchTree T );

        #endif  /* _MyTree_H */

/* END */
