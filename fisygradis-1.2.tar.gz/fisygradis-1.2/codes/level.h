/* level.h */

#ifndef LEVEL_H
#define LEVEL_H

#include <GL/gl.h>
#define PI 3.141592653
#define MAX_PATH 200
#define BRANCH 20

//extern char* found;
extern GLfloat xpos, zpos, level;
extern GLfloat obs[3];
extern GLfloat in[3];
extern GLfloat depth;

extern struct  store 
{
  int anode;
  char* apath;
}st;

extern void do_a_directory(char * pathname, GLfloat xpos, GLfloat zpos, GLfloat level, GLenum mode);
extern void do_a_file(char * pathname, GLfloat xpos, GLfloat zpos);

#endif
