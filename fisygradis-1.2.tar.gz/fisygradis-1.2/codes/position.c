/** @file position.c 
  @brief File used to hold some function such as help and info display, It also holds the camera's movement algorithm in calcposobs.
 * This program is under the GNU GPL.
 * Use at your own risk
 
    @author Francois Gez
    @date 08/04/2007
*/

/*This is for stat() function directory access*/
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>

/*OpenGL stuffs*/
#include <stdio.h>
#include <stdlib.h> 
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <GL/glut.h>
#include "position.h"


#define FOV 85
#define WIDTH 1200
#define HEIGHT 800
#define DATA_DIR "/usr/share/fisygradis/"


char *path = "./";
static char frbuf[80];
static char ofbuf[80];
static char coorbuf[80];

GLint T0 = 0;
GLint Frames = 0;
GLint inside = 0;

int helpmenu = 1;
int helpinfo = 1;
int poutline = 1;
int fog = 0;
int bfcull = 1;
int usetex = 1;
int hide_names = 1;
int hide_coord = 1;
int hide_time = 1;
int hide_size = 1;
GLuint material_mode = 0;		/* 0=none, 1=color, 2=material */

float obs[3] = { 0.0, 0.0, 0.0 };//position observer in outer world
float in[3] = { 0.0, 0.0, 0.0 };//Position observer in inner world
float dir[3] = { 0.0, 0.0, 0.0 };//Direction observer in outer world
float indir[3] = { 0.0, 0.0, 0.0 };//Direction observer in inner world
float v = 0.0;
float zoom = 1.0;
float expand = 1.0;
float alpha = -5.0;
float beta = 75.0;
float inalpha = -5.0;
float inbeta = 75.0;
int cursor = 0;

char* model_file[] = {DATA_DIR"eiffel.obj", DATA_DIR"sphinx.obj", DATA_DIR"suitcase.obj", DATA_DIR"dvd.obj", DATA_DIR"pen.obj", DATA_DIR"globe.obj",DATA_DIR"book.obj", DATA_DIR"camera.obj", DATA_DIR"warncone.obj", DATA_DIR"presentation.obj", DATA_DIR"clock.obj", DATA_DIR"head.obj", DATA_DIR"music.obj", DATA_DIR"jukebox.obj", DATA_DIR"shovel.obj", DATA_DIR"calculator.obj", DATA_DIR"camcorder.obj"}; /* name of the object file */

GLboolean  facet_normal = GL_FALSE;	/* draw with facet normal? */
GLMmodel*  model;			        /* glm model data structure */
GLfloat    scale;			        /* original scale factor */
GLfloat    smoothing_angle = 90.0;	/* smoothing angle */



/** This function provides the use of string display in the 3D world 
    @return void there is nothing to return here.
    @param x float position of the text on the x coordinate. 
    @param y float position of the text on the y coordinate.     
    @param string char[] The array that holds the string of text. 
*/
void 
output(float x, float y, char string[])
{
  int len,i;

  glColor3f(1.0, 1.0, 1.0);
  glRasterPos2f(x, y);
  len = (int) strlen(string);
  for(i=0; i<len; i++)
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, string[i]);
}

/** This function provides the use of string display in the 3D world, similar to the previous function, but with a option for a different font type.  
    @return void there is nothing to return here.
    @param font void* the font type here.
    @param string char* The pointer to char that holds the string.     
*/
void
printstring(void *font, char *string)
{
  int len, i;
  
  len = (int) strlen(string);
  for (i = 0; i < len; i++)
    glutBitmapCharacter(font, string[i]);
}

/** This function displays the menu.   
    @return void there is nothing to return here.
    @param void there is no parameters here.
*/
void 
printhelp(void) 
{
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_BLEND);
  
  glColor3f(1.0, 0.0, 0.0);
  glRasterPos2i(300, 210);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "Help");
  
  glRasterPos2i(40, 420);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "ESC - Terminate Program");
  glRasterPos2i(60, 400);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "S - Toggle File Size");
  glRasterPos2i(60, 380);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "T - Toggle Time Access");  
  glRasterPos2i(60, 360);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "h - Toggle Help");
  glRasterPos2i(60, 340);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "t - Toggle Textures");
  glRasterPos2i(60, 320);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "f - Toggle Fog");
  glRasterPos2i(60, 300);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "p - Wire frame");
  glRasterPos2i(60, 280);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "b - Toggle Back face culling");
  glRasterPos2i(60, 260);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "Arrow Keys - Rotate");
  glRasterPos2i(60, 240);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "a - Increase velocity");
  glRasterPos2i(60, 220);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "z - Decrease velocity");
  glRasterPos2i(60, 200);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "n - Toggle object's name");
  glRasterPos2i(60, 180);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "c - Toggle object's detail");  
  glRasterPos2i(60, 160);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "s - Stop the camera");  
  glRasterPos2i(60, 140);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "i - Toggle informations");  
  glRasterPos2i(60, 120);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "TAB - Back to initial position");   
  glRasterPos2i(60, 100);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "+/- - Zoom in and out");
  glRasterPos2i(60, 80);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "e/E - Expand tree up and down");
  glRasterPos2i(60, 60);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "LMC/RMC - Toggle inner and outer directory");
  glRasterPos2i(60, 40);
  printstring(GLUT_BITMAP_TIMES_ROMAN_24, "C - Toggle cursor position");  
}

/** This function displays some informations such as camera position and speed.   
    @return void there is nothing to return here.
    @param void there is no parameters here.
*/
void 
printinfo(void)
{
  glColor3f(1.0, 0.0, 0.0);   
  glRasterPos2i(10, 30);
  printstring(GLUT_BITMAP_HELVETICA_18, path);
  glRasterPos2i(420, 10);
  printstring(GLUT_BITMAP_HELVETICA_18, ofbuf);
  glRasterPos2i(10, 10);
  printstring(GLUT_BITMAP_HELVETICA_18, frbuf);
  glRasterPos2i(140, 10);
  printstring(GLUT_BITMAP_HELVETICA_18, coorbuf); 
  glRasterPos2i(210, 460);
  printstring(GLUT_BITMAP_HELVETICA_10, "FiSyGraDis V1.0 Written by Francois Gez (francoisgez2002@gmail.com)");
  glRasterPos2i(254, 450);
  printstring(GLUT_BITMAP_HELVETICA_10, "Based on a Mickael's demo (Skizo@Hol.Fr)");
  
  Frames++;
  GLint t = glutGet(GLUT_ELAPSED_TIME);
  if (t - T0 >= 2000) {
    GLfloat seconds = (t - T0) / 1000.0;
    GLfloat fps = Frames / seconds;
    sprintf(frbuf, "Frame rate: %f", fps);
    sprintf(ofbuf, "Observer speed: %.0f", v);
    sprintf(coorbuf, "Camera coordinates: %.3f %.3f %.3f", obs[0], obs[1], obs[2]);
    T0 = t;
    Frames = 0;
  }
}

/** This function provides the control of the keyboard.   
    @return void there is nothing to return here.
    @param k unsigned char the char variable used by the swith statement. 
    @param x int a variable needed here.
    @param y int a variable needed here. 
*/
void
key(unsigned char k, int x, int y)
{
  switch (k) {
  case 27:
    exit(1);  
    break;
  case 's':
    v = 0.0;
    break;
  case 9:
    //to implement with initial observer location
   obs[0] = 0.0;
   obs[1] = 0.0;
   obs[2] = 0.0;
   alpha = -5.0;
   beta = 75.0;
   break;
  case 'S':
    hide_size = (!hide_size);   
    break;
  case 'a':
    v += 2.0;
    break;
  case 'z':
    v -= 2.0; 
    break;
  case '+':
    if(zoom > 20.0)
      zoom = 20.0;
    else
      zoom += 1.0; 
    break;
  case '-':
    if(zoom < 1.0)
      zoom = 1.0;
    else
      zoom -= 1.0; 
    break;
  case 'e':
    if(expand < 1.0)
      expand = 1.0;
    else
      expand -= 1.0; 
    break;
  case 'E':
    if(expand > 20.0)
      expand = 20.0;
    else
      expand += 1.0; 
    break;
  case 'p':
    if (poutline) {
      glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
      poutline = 0;
    }
    else {
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
      poutline = 1;
    }
    break;
  case 'h':
    helpmenu = (!helpmenu);
    break;
  case 'f':
    fog = (!fog);
    break;
  case 't':
    usetex = (!usetex);
    break;
  case 'T':
    hide_time = (!hide_time);
    break;
  case 'n':
    hide_names = (!hide_names);
    break;
  case 'C':
    (cursor>19) ? cursor=0 : glutSetCursor(cursor++);
    break;
  case 'c':
    hide_coord = (!hide_coord);
    break;  case 'i':
    helpinfo = (!helpinfo);
    break;
  case 'b':
    if (bfcull) {
      glDisable(GL_CULL_FACE);
      bfcull = 0;
    }
    else {
      glEnable(GL_CULL_FACE);
      bfcull = 1;
    }
    break;
  }
}

/** This function provides a specific handling of the arrow keys.   
    @return void there is nothing to return here.
    @param k int a variable needed here. 
    @param x int a variable needed here.
    @param y int a variable needed here. 
*/
void
special(int k, int x, int y)
{
 printf("Inside is: %d\n", inside);

 switch (k) {
 case GLUT_KEY_LEFT:
   if(inside == 0)
     alpha -= 5.0;
else
  inalpha -= 5.0;
   break;
 case GLUT_KEY_RIGHT:
   if(inside == 0)
     alpha += 5.0;
   else
     inalpha += 5.0;
   break;
 case GLUT_KEY_DOWN:
   if(inside == 0)
     beta += 5.0;
   else
     inbeta += 5.0;
   break;
 case GLUT_KEY_UP:
   if(inside == 0)
     beta -= 5.0;
   else
     inbeta -= 5.0;
   break;
 }
}

/** This function is controling the movement and speed of the camera in the world.  
 * Use of this function
 * written by David Bucciarelli (tech.hmw@plus.it)
 *            Humanware s.r.l.	
 *
 * based on a Mikael SkiZoWalker's (MoDEL) / France (Skizo@Hol.Fr) demo
 *
    @return void there is nothing to return here.
    @param void there is no parameters here.
*/
void
calcposobs(void)
{
   static double t0 = -1.0;
   double dt, t = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
   if (t0 < 0.0)
     t0 = t;
   dt = t - t0;
   t0 = t;
   
   dir[0] = sin(alpha * M_PI / 180.0);
   dir[1] = cos(alpha * M_PI / 180.0) * sin(beta * M_PI / 180.0);
   dir[2] = cos(beta * M_PI / 180.0);
   
   if (dir[0] < 1.0e-5 && dir[0] > -1.0e-5)
      dir[0] = 0;
   if (dir[1] < 1.0e-5 && dir[1] > -1.0e-5)
      dir[1] = 0;
   if (dir[2] < 1.0e-5 && dir[2] > -1.0e-5)
      dir[2] = 0;

   obs[0] += v * dir[0] * dt;
   obs[1] += v * dir[1] * dt;
   obs[2] += v * dir[2] * dt;
}

/** This function is controling the movement and speed of the camera in the world.  
 * Use of this function
 * written by David Bucciarelli (tech.hmw@plus.it)
 *            Humanware s.r.l.	
 *
 * based on a Mikael SkiZoWalker's (MoDEL) / France (Skizo@Hol.Fr) demo
 *
    @return void there is nothing to return here.
    @param void there is no parameters here.
*/
void
calcposin(void)
{
   static double t0 = -1.0;
   double dt, t = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
   if (t0 < 0.0)
      t0 = t;
   dt = t - t0;
   t0 = t;

   indir[0] = sin(inalpha * M_PI / 180.0);
   indir[1] = cos(inalpha * M_PI / 180.0) * sin(inbeta * M_PI / 180.0);
   indir[2] = cos(inbeta * M_PI / 180.0);

   if (indir[0] < 1.0e-5 && indir[0] > -1.0e-5)
      indir[0] = 0;
   if (indir[1] < 1.0e-5 && indir[1] > -1.0e-5)
      indir[1] = 0;
   if (indir[2] < 1.0e-5 && indir[2] > -1.0e-5)
      indir[2] = 0;

   in[0] += v * indir[0] * dt;
   in[1] += v * indir[1] * dt;
   in[2] += v * indir[2] * dt;
}

void drawObject(char *file_path)
{

  /* read in the model */
  model = glmReadOBJ(file_path);
  scale = glmUnitize(model);
  glmFacetNormals(model);
  glmVertexNormals(model, smoothing_angle);
  glmDraw(model, GLM_SMOOTH | GLM_MATERIAL);
}
