 /*http://www.cs.fiu.edu/~weiss/dsaa_c2e/files.html*/

#include <string.h>
#include "tree.h"
#include <stdlib.h>
#include "fatal.h"
#define MAX 200

int i = 0;
  int count = 0;

struct TreeNode
{
  struct stat buf;
int anode;
  char apath[MAX];
  SearchTree  Left;
  SearchTree  Right;
};

/* START: */
SearchTree
MakeEmpty( SearchTree T )
{
  if( T != NULL )
    {
      MakeEmpty( T->Left );
      MakeEmpty( T->Right );
      free( T );
    }
  return NULL;
}
/* END */


/* END */

/* START: */
SearchTree
Insert(struct stat astat, int inode, char apath[], SearchTree T )
{ 
  int i;
  if( T == NULL )
    {
      /* Create and return a one-node tree */
      T = malloc( sizeof( struct TreeNode ) );
      if( T == NULL )
	FatalError( "Out of space!!!" );
      else
	{
	  T->buf = astat;
	  T->anode = inode;
	  for(i=0;i<MAX;i++)
	    {
	      T->apath[i] = apath[i];
	    }
	   
	  T->Left = T->Right = NULL;
	}
    }
  else
    {

	if( inode < T->anode )
	  T->Left = Insert(astat, inode, apath, T->Left );
	else
	  if( inode > T->anode)
	    T->Right = Insert(astat, inode, apath, T->Right );
	//else
	/* Else X is in the tree already; we'll do nothing */	    
    }
	return T;  /* Do not forget this line!! */  
}
/* END */



char* FindPath( int inode, SearchTree T )
{
    if( T == NULL )
      {
    printf("Tree is empty\n");
    return NULL;
      }
    else
      {	  
	
	if(inode < T->anode)

	    FindPath( inode, T->Left );
	  
	else
	  if( inode > T->anode )

	    FindPath( inode, T->Right );
	  
	  else if(inode == T->anode)
	    
	      return T->apath;
	    
	
	  else
	    return "found NOTHING";      
      }    
}



    
