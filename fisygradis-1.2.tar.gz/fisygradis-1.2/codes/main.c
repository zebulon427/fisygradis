/*     
 * Main program file
 */

/* 
 * Standard header files
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>
#include <GL/glut.h>
#include <string.h>
/*
 * Application specific header files
 */
#include "readtex.h"  
#include "position.h"
#include "level.h"
#include "tree.h"
#include "component.h"

/*
 * Platform specific header files
 */
#if defined(_WIN32)
#include <sys/timeb.h>
#define CLK_TCK 1000
#else
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/times.h>
#endif

/*
 * Read-only data
 */


#define DATA_DIR "/usr/share/fisygradis/"
#define CLK_TCK 1000
#define FOV 85
#define MAX_GRID_SIZE 40
#define SIZE (MAX_GRID_SIZE * MAX_GRID_SIZE * MAX_GRID_SIZE)

/*
 * Data variables
 */
GLuint    texture_id[MAX_NO_TEXTURES];
char* newpath = "?";
GLfloat    weld_distance = 0.00001;	/* epsilon for welding vertices */
GLboolean  stats = GL_FALSE;		/* statistics on? */
GLint      entries = 0;			    /* entries in model menu */
static int winWidth = 1200;
static int winHeight = 800;//calcposobs function data

/*
 *Mouse variables 
 */
GLenum mode;
GLfloat fovy = 45.0, aspect = 1.0, near = 1.0, far = 100.0;

/*  processHits prints out the contents of the 
 *  selection array.
 */
void processHits (GLint hits, GLuint buffer[])
{
   GLint i, j;
   GLuint names = 0, *ptr;
   GLuint nearest_depth_val, nearest_name = 0;
   printf ("hits = %d\n", hits);
   ptr = buffer; 

   for (i = 0; i < hits; i++, ptr+=(3+names)) {	/*  for each hit  */
      names = *ptr;

      if( !i ) { /* First hit */
        nearest_depth_val = *(ptr+1);
        nearest_name = *(ptr+3);
      }
      else if( *(ptr+1) < nearest_depth_val ) { /* Nearer */
        nearest_depth_val = *(ptr+1);
        nearest_name = *(ptr+3);
      }
   }

   if( nearest_name ) {
     newpath = FindPath(nearest_name, T);
     printf("Inode is %d and path is %s\n", nearest_name, newpath);
     glutPostRedisplay();
   }
   else 
     printf("No directory picked\n");   
}


void mouse(int button, int state, int x, int y)
{
  GLuint selectBuf[SIZE];
  GLint hits;
  GLint viewport[4];
  
  if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) 
    {
      glGetIntegerv (GL_VIEWPORT, viewport);
      
      glSelectBuffer (SIZE, selectBuf);
      glRenderMode(GL_SELECT);
      
      glInitNames();
      glPushName(0);
      
      glMatrixMode (GL_PROJECTION);
      glPushMatrix ();
      glLoadIdentity ();

      /*  create 5x5 pixel picking region near cursor location	*/
      gluPickMatrix ((GLdouble) x, (GLdouble) (viewport[3] - y), 5.0, 5.0, viewport);
      gluPerspective( fovy, aspect, near, far );
      drawDirectory(GL_SELECT);     
      glMatrixMode (GL_PROJECTION);
      glPopMatrix ();
      glFlush ();
      
      hits = glRenderMode (GL_RENDER);
      processHits (hits, selectBuf);
      inside = 1;
      glutPostRedisplay();
    }
  
  else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN && inside == 1) 
    {
      inside = 0;
      glutPostRedisplay();
    }
} 

void drawDirectory(GLenum mode)
{
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   /* Viewpoint */
   gluLookAt(obs[0], obs[1], obs[2],obs[0] + dir[0], obs[1] + dir[1], obs[2] + dir[2],0.0, 0.0, 1.0); 
   glScalef( zoom, zoom, zoom*expand );    /* scale the scene */ 
   
   if(path == NULL)
     {
       path =  "./";
       do_a_directory(path, 0.0, 0.0, 0.0, mode);
     }
   else  
     do_a_directory(path, 0.0, 0.0, 0.0, mode);
   
   inside = 0;
}

void drawFile(GLenum mode)
{
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  /* Viewpoint */  
  gluLookAt(in[0], in[1], in[2], in[0] + indir[0], in[1] + indir[1], in[2] + indir[2],0.0, 0.0, 10.0); 
  glScalef( zoom, zoom, zoom*expand );    /* scale the scene */   
  do_a_file(newpath, 0.0, 0.0);
  inside = 1;
}


void
reshape(int width, int height)
{
  winWidth = width;
  winHeight = height;
  
  /* projection transformation */
  glViewport (0, 0, (GLsizei) winWidth, (GLsizei) winHeight);     
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(50.0, (GLfloat)winWidth / (GLfloat)winHeight, 1.0, 8000.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  
  glutSetCursor(cursor);  
}


void
display(GLenum mode)
{    
  glClearColor(0.1, 0.0, 0.3, 0.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);   
  glEnable( GL_DEPTH_TEST );
  
  /* projection transformation */
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity();
  gluPerspective(50.0, (GLfloat)winWidth / (GLfloat)winHeight, 1.0, 1000.0);
  
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();  
  glPushMatrix();  
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_GEN_S);
  glEnable(GL_TEXTURE_GEN_T);
  glEnable(GL_LIGHTING);

   if (usetex)
     glEnable(GL_TEXTURE_2D);
   else
     glDisable(GL_TEXTURE_2D);
   
   if (fog)
     glEnable(GL_FOG);
   else
     glDisable(GL_FOG);
      
   if(inside == 0) 
     drawDirectory(GL_RENDER);
   
   else if(inside == 1)
     drawFile(GL_RENDER);
   
   glDisable(GL_LIGHTING);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_GEN_S);
   glDisable(GL_TEXTURE_GEN_T);    
   glPopMatrix();  
   
   
   glPushMatrix();  
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-0.5, 639.5, -0.5, 479.5, -1.0, 1.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   
   if(helpmenu)  
     printhelp();
   
   if(helpinfo)
     printinfo();
   glPopMatrix();
   
   glEnable(GL_LIGHTING);      
   glutSwapBuffers();
   glutPostRedisplay();
}


int
main(int argc, char** argv)
{
    int buffering = GLUT_DOUBLE;
    struct dirent* direntp;
    DIR* dirp;
    int models;
    path = argv[1];

    glutInitWindowSize(winWidth, winHeight);
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | buffering);
    glutCreateWindow("FiSyGraDis");    

    //If you want fullscreen, just enter your screen size here
    /*    
#ifndef WIN32
    glutGameModeString("1024x768:16@60");
#else
    glutGameModeString("width=1024;height=768;bpp=16;");
#endif
    

    // enter game mode
    glutEnterGameMode();
    */
    glutMouseFunc (mouse);
    glutReshapeFunc(reshape);
    glutDisplayFunc(display);
    glutSpecialFunc(special);
    glutKeyboardFunc(key); 
    
    init();
    
    glutMainLoop();
    return 0;
}
