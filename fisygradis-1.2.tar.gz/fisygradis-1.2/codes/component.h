/* component.h */

#ifndef COMPONENT_H
#define COMPONENT_H

#include <GL/gl.h>

#define   MAX_NO_TEXTURES 2

#define   GOLD_TEXTURE   0
#define   MARBLE_TEXTURE   1


extern int cube, cylinder, plate, torus, cage;
extern void BuildCylinder(int numEdges);
extern void BuildPlate(int numEdges);
extern void BuildTorus(float rc, int numc, float rt, int numt);
extern void BuildCage(void);
extern void BuildCube(void);
extern void BuildLists(void);
extern void Init(void);
extern void Draw(void);
extern GLuint texture_id[MAX_NO_TEXTURES];
#endif
